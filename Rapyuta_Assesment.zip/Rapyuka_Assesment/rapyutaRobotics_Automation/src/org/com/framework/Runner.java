package org.com.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Runner {
	public static Properties P;
	
	//static driverClass Driver=new driverClass();

	public static void main(String[] args) throws IOException, ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		// TODO Auto-generated method stub
		driverClass Driver=new driverClass();
		
FileInputStream input=new FileInputStream(new File(".//src//config.properties"));
		
		P=new Properties();
		
		P.load(input);
		
		
		reporter.PathInitilization();
		utility.CallTestCases();
       reporter.EndReport();
		

	}

}
