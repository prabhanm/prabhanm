package org.com.framework;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class driverClass {
	
public static long globalWait;
	
	public static WebDriver driver;
	
	public static WebDriver launchDriver() throws IOException {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Learning docs\\Selenium Code\\chromedriver_88.exe");
		/*Runtime rt = Runtime.getRuntime();
		Process proc = rt.exec("taskkill /im chrome.exe /f /t");
		Process proc1 = rt.exec("taskkill /im chromedriver.exe /f /t");*/
		/*ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-web-security");
		option.addArguments("--test-type");
		option.addArguments("--allow-running-insecure-content");
		option.addArguments("--dns-prefetch-disable");
		option.addArguments("--no-sandbox");
		
		
		DesiredCapabilities capabilities=DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
		capabilities.setCapability(ChromeOptions.CAPABILITY, option);
		capabilities.setCapability("autoDismissAlerts", true);
		
		driver=new ChromeDriver(capabilities);*/
		driver=new ChromeDriver();
		driver.manage().deleteAllCookies();
		
		driver.get(Runner.P.getProperty("URL"));
		
		//driver.get("http://zipresuat.radixxuat.com/Login");
		
		driver.manage().window().maximize();
		
		 long wait=Long.parseLong(Runner.P.getProperty("WaitTime"));
		
		driver.manage().timeouts().implicitlyWait(wait, TimeUnit.SECONDS);
		
		return driver;
		
	}

}
