package org.com.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.com.testCases.caseScript;
import org.openqa.selenium.WebDriver;

import com.google.common.collect.Table.Cell;

public class utility {
	
public static void CallTestCases() throws IOException, ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		File file=new File(Runner.P.getProperty("InputSheetPath"));
		FileInputStream input = new FileInputStream(file);
		XSSFWorkbook workbook=new XSSFWorkbook(input);
		Sheet sheet=workbook.getSheet(Runner.P.getProperty("SheetName"));
		Row row ;
		Cell cell;
		
		int rowNum=sheet.getLastRowNum();
		
		for(int i=1;i<=rowNum;i++) {
			row=sheet.getRow(i);
			
			double active=row.getCell(1).getNumericCellValue();
			
			if(active==0) {
				continue;
			}
			String testName=row.getCell(0).getStringCellValue();
			
			reporter.StartTest(testName);
			
			System.out.println(testName);
			
			Class c=Class.forName("org.com.testCases.caseScript");
			Object t = c.newInstance();
			Method mtd=t.getClass().getMethod(testName);
			mtd.invoke(t);
			
			
			commonMethods.closeDriver();
			reporter.EndTest();

			
			
		}
}

}
