package org.com.framework;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class reporter {
	
static DateFormat format=new SimpleDateFormat("yyyy-MM-dd");
	
	static String date=format.format(new Date());

	public static ExtentReports report;
	public static ExtentTest logger;
	
	public static void PathInitilization() {
		report=new ExtentReports(System.getProperty("user.dir")+"\\Reports\\"+date+"\\ExecutionReport"+System.currentTimeMillis()+".html",true);
	}
		public static void StartTest(String caseName) {
		logger=report.startTest(caseName);
	}
	
	public static void EndTest() {
		
		report.endTest(logger);
	}
	public static void EndReport() {
		report.flush();
		
		
	}

}
