package org.com.framework;

import org.openqa.selenium.By;

public class OR {
	
	public static By Username=By.xpath("//input[@data-id='username']");
	public static By Password=By.xpath("//input[@data-id='password']");
	public static By loginButton=By.xpath("//button[text()='Login']");
	public static By manageIcon=By.xpath("//a[@href='/manage']");
	public static By mapDropdown=By.xpath("//button[contains(@class,'ant-btn ant-dropdown-trigger button-dropdown')]");
	public static By loginError=By.xpath("//p[text()='Error in logging in. Try again']");

}
