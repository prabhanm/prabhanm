package org.com.framework;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.LogStatus;

public class commonMethods extends driverClass {
	
//driverClass newDriver=new driverClass();

	
		
	public static String CaptureScreenShot() throws IOException {
		
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		
		String date=format.format(new Date());
		
		TakesScreenshot shots=((TakesScreenshot)driver);
		
		File source=shots.getScreenshotAs(OutputType.FILE);
		
		File destination=new File (".\\zipAir\\ScreenShots\\"+date+"\\test_"+System.currentTimeMillis()+".png");
		FileUtils.copyFile(source, destination);
		
		String SSPath=destination.getAbsolutePath();
		
		return SSPath;
		}
	
	
	public static void FailedScreenshot(String Reason) throws IOException {
		reporter.logger.log(LogStatus.FAIL,reporter.logger.addScreenCapture(CaptureScreenShot())+" "+Reason);
	}
	
	
	public static void passScreenshot(String Reason) throws IOException {
		reporter.logger.log(LogStatus.PASS,reporter.logger.addScreenCapture(CaptureScreenShot())+" "+Reason);
	}
	
	
	public static void closeDriver() {
		driver.quit();
	}
	
   
   public static void clickOnButton(By path ) {
	 
	  driver.findElement(path).click();
   }
   
   public static void getTitle() {
		 
		  driver.getTitle();
	   }
   
		   
public static void selectFromDropdown(By dropdwon, String value ) {
	  
	 Select select=new Select(driver.findElement(dropdwon));
	  select.selectByVisibleText(value);
 }
 public static boolean CheckEnability (By path ) {
	   boolean flag = false;
	   WebElement validation=driver.findElement(path);
	   
	   if(validation.isEnabled()==true) {
		   flag=true;
	   }
	   return flag;
	   }
 
 public static void EnterText(By fieldPath, String text ) {
	 
	   driver.findElement(fieldPath).sendKeys(text);
	   }
 
	public static void MouseHover(By path )
	 {
		try {
			WebElement mouseHover=driver.findElement(path);
			
					 Actions action=new Actions(driver);
		 action.moveToElement(mouseHover).build().perform();
		}catch(Exception e) {
			 reporter.logger.log(LogStatus.FAIL, "Mouse does not hover over element");
		}
		   }
	public static void SelectCheckBox(By path, String value) {
		
			if(value.equals("Yes")) {
			commonMethods.clickOnButton(path);
			//reporter.logger.log(LogStatus.PASS,"user successfully checked box");
			}
	}
	
	
	
	
	
	

}
