package org.com.testCases;

import java.io.IOException;

import org.com.framework.OR;
import org.com.framework.Runner;
import org.com.framework.commonMethods;
import org.com.framework.driverClass;
import org.com.framework.reporter;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

public class caseScript extends driverClass {
	
	public void TC_01() throws IOException {
		try {
			driverClass.launchDriver();
			
		commonMethods.EnterText(OR.Username, Runner.P.getProperty("UserName"));
		commonMethods.EnterText(OR.Password, Runner.P.getProperty("Password"));
		commonMethods.passScreenshot("User has entered Credentials successfully" );
		
		commonMethods.clickOnButton(OR.loginButton);
		
		Thread.sleep(5000);
		
		String title=driver.getTitle();
		
		if(title.equals("Rapyuta Robotics")) {
			commonMethods.passScreenshot("User has navigated to home page successfully" );
			
			System.out.println(title);
			
		}else {
			commonMethods.FailedScreenshot("Login has failed" );
		}
			
		}
		catch(Exception e){
			System.out.println("Catch Block");
			
			reporter.logger.log(LogStatus.FAIL,  "Loggin not susscessful", e);
			e.printStackTrace();
		}
	}
	
	public void TC_02() throws IOException {
		try {
			driverClass.launchDriver();
			
		commonMethods.EnterText(OR.Username, Runner.P.getProperty("WrongUser"));
		commonMethods.EnterText(OR.Password, Runner.P.getProperty("Password"));
		
		commonMethods.passScreenshot("User has entered Credentials successfully" );
		commonMethods.clickOnButton(OR.loginButton);
		
		String title=driver.findElement(OR.loginError).getText();
		
		if(title.equals("Error in logging in. Try again")) {
			commonMethods.passScreenshot("User restricted for login");
			
			System.out.println(title);
			
		}else {
			commonMethods.FailedScreenshot("User logged in successfully with incorrect credentials");
		}
			
		}
		catch(Exception e){
			System.out.println("Catch Block");
			
			reporter.logger.log(LogStatus.FAIL,  "Loggin not susscessful", e);
			e.printStackTrace();
		}
		
	}


}
